import React, { useState } from 'react'
import Header from '../components/Header'
import Sidebar from '../components/Sidebar'
import FilterBar from '../components/FilterBar'
import VideoCard from '../components/VideoCard'
import videos from '../data/videos'
import './Home.css'

const Home = ({ showSidebar, setShowSidebar }) => {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('All')

  const handleSearch = (e) => {
    setSearchTerm(e.target.value.toLowerCase())
  }

  const handleCategory = (category) => {
    setSelectedCategory(category)
  }

  const filteredVideos = videos.filter(video => {
    const matchesTitle = video.title.toLowerCase().includes(searchTerm)
    const matchesCategory = selectedCategory === 'All' || video.category === selectedCategory
    return matchesTitle && matchesCategory
  })

  return (
    <div>
      <Header onSearch={handleSearch} onToggleSidebar={() => setShowSidebar(prev => !prev)} />

      <div className={`home-layout ${showSidebar ? 'sidebar-expanded' : 'sidebar-collapsed'}`}>
        <Sidebar collapsed={!showSidebar} />
        <main className="main-content">
          <FilterBar onSelectCategory={handleCategory} selected={selectedCategory} />
          <div className="video-grid">
            {filteredVideos.map(video => (
              <VideoCard key={video.videoId} video={video} />
            ))}
          </div>
        </main>
      </div>
    </div>
  )
}

export default Home

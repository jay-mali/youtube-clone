import React, { useState, useContext } from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'
import { AuthContext } from '../context/AuthContext'
import './CreateChannel.css'

const CreateChannel = () => {
  const [channelName, setChannelName] = useState('')
  const [handle, setHandle] = useState('')
  const [avatar, setAvatar] = useState(null)
  const [preview, setPreview] = useState(null)
  const [loading, setLoading] = useState(false)

  const { user, refreshUser } = useContext(AuthContext)
  const navigate = useNavigate()

  const handleAvatarChange = (e) => {
    const file = e.target.files[0]
    setAvatar(file)
    setPreview(URL.createObjectURL(file))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!channelName || !handle) {
      alert('Please fill out all fields')
      return
    }

    try {
      setLoading(true)
      const token = localStorage.getItem('token')

      let avatarUrl = ''
      if (avatar) {
        const reader = new FileReader()
        reader.readAsDataURL(avatar)
        await new Promise(resolve => {
          reader.onloadend = () => {
            avatarUrl = reader.result
            resolve()
          }
        })
      }

      await axios.post(
        'http://localhost:5000/api/channel/create',
        {
          name: channelName,
          handle: `@${handle}`,
          avatar: avatarUrl,
        },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      )

      await refreshUser() // refresh to get channel in context
      alert('✅ Channel created successfully!')
      navigate('/')
    } catch (err) {
      alert(err.response?.data?.message || 'Channel creation failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="create-channel-page">
      <h2>Create Your Channel</h2>
      <form onSubmit={handleSubmit}>
        <label>Channel Name:</label>
        <input
          type="text"
          value={channelName}
          onChange={(e) => setChannelName(e.target.value)}
          placeholder="Enter channel name"
          required
        />

        <label>Channel Handle:</label>
        <input
          type="text"
          value={handle}
          onChange={(e) => setHandle(e.target.value)}
          placeholder="yourname123"
          required
        />

        <label>Upload Profile Picture:</label>
        <input type="file" accept="image/*" onChange={handleAvatarChange} />
        {preview && <img src={preview} alt="avatar preview" className="avatar-preview" />}

        <button type="submit" disabled={loading}>
          {loading ? 'Creating...' : 'Create Channel'}
        </button>
      </form>
    </div>
  )
}

export default CreateChannel

import React, { useState, useContext } from 'react'
import { useParams, Link } from 'react-router-dom'
import videos from '../data/videos'
import channels from '../data/channels'
import { AuthContext } from '../context/AuthContext'
import './VideoPlayer.css'

const VideoPlayer = () => {
  const { id } = useParams()
  const { user } = useContext(AuthContext)
  const video = videos.find(v => v.videoId === id)
  const channel = channels.find(c => c.channelId === video?.channelId)

  const [comments, setComments] = useState(video?.comments || [])
  const [newComment, setNewComment] = useState('')
  const [editingId, setEditingId] = useState(null)
  const [editText, setEditText] = useState('')

  const [likes, setLikes] = useState(video?.likes || 0)
  const [dislikes, setDislikes] = useState(video?.dislikes || 0)
  const [userReaction, setUserReaction] = useState(null)

  if (!video) return <h2>Video not found</h2>

  const handleLike = () => {
    if (userReaction === 'like') {
      setLikes(likes - 1)
      setUserReaction(null)
    } else {
      setLikes(likes + 1)
      if (userReaction === 'dislike') setDislikes(dislikes - 1)
      setUserReaction('like')
    }
  }

  const handleDislike = () => {
    if (userReaction === 'dislike') {
      setDislikes(dislikes - 1)
      setUserReaction(null)
    } else {
      setDislikes(dislikes + 1)
      if (userReaction === 'like') setLikes(likes - 1)
      setUserReaction('dislike')
    }
  }

  const handleCommentSubmit = (e) => {
    e.preventDefault()
    if (!newComment.trim()) return

    const comment = {
      commentId: `c${Date.now()}`,
      userId: user?.id,
      username: user?.username,
      text: newComment,
      timestamp: new Date().toISOString()
    }

    setComments([comment, ...comments])
    setNewComment('')
  }

  const handleDelete = (commentId) => {
    if (window.confirm('Delete this comment?')) {
      setComments(comments.filter(c => c.commentId !== commentId))
    }
  }

  const handleEdit = (commentId, text) => {
    setEditingId(commentId)
    setEditText(text)
  }

  const handleEditSubmit = (e, commentId) => {
    e.preventDefault()
    setComments(comments.map(c =>
      c.commentId === commentId ? { ...c, text: editText } : c
    ))
    setEditingId(null)
    setEditText('')
  }

  return (
    <div className="video-player-page">
      <div className="video-frame">
        <iframe
          width="100%"
          height="500"
          src={`https://www.youtube.com/embed/${video.videoId}`}
          title={video.title}
          frameBorder="0"
          allowFullScreen
        />
      </div>

      <div className="video-info-section">
        <h2>{video.title}</h2>
        <p>{video.views.toLocaleString()} views • {video.uploadDate}</p>

        <div className="video-reactions" style={{ display: 'flex', gap: '16px', marginTop: '8px' }}>
          <button
            onClick={handleLike}
            style={{
              color: userReaction === 'like' ? '#0f0' : '#aaa',
              background: 'transparent',
              border: 'none',
              cursor: 'pointer',
              fontSize: '16px'
            }}
          >
            👍 {likes}
          </button>
          <button
            onClick={handleDislike}
            style={{
              color: userReaction === 'dislike' ? '#f55' : '#aaa',
              background: 'transparent',
              border: 'none',
              cursor: 'pointer',
              fontSize: '16px'
            }}
          >
            👎 {dislikes}
          </button>
        </div>

        <p>
          Uploaded by:{" "}
          <Link to={`/channel/${channel?.channelId}`} className="channel-link">
            {video.uploader}
          </Link>
        </p>
      </div>

      <div className="comments-section" style={{ background: '#111', padding: '20px', borderRadius: '10px', marginTop: '20px' }}>
        <h3 style={{ color: 'gold' }}>Comments</h3>

        {user ? (
          <form className="comment-form" onSubmit={handleCommentSubmit}>
            <input
              type="text"
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              placeholder="Add a comment..."
              className="comment-input"
              style={{ width: '80%', padding: '10px', background: '#222', color: 'white', border: '1px solid #555' }}
            />
            <button type="submit" className="comment-submit" style={{ marginLeft: '10px', padding: '10px', background: 'gold', color: '#000' }}>
              Post
            </button>
          </form>
        ) : (
          <p style={{ color: '#ccc' }}>Please sign in to comment.</p>
        )}

        {comments.map((c) => (
          <div key={c.commentId} className="comment" style={{ color: 'white', padding: '10px 0', borderBottom: '1px solid #333' }}>
            <p className="comment-user" style={{ color: '#ddd' }}>{c.username}</p>
            {editingId === c.commentId ? (
              <form onSubmit={(e) => handleEditSubmit(e, c.commentId)}>
                <input
                  type="text"
                  value={editText}
                  onChange={(e) => setEditText(e.target.value)}
                  className="comment-input"
                  style={{ padding: '8px', width: '70%', background: '#222', color: 'white' }}
                />
                <button type="submit" className="comment-submit" style={{ marginLeft: '8px', padding: '8px', background: 'gold', color: '#000' }}>
                  Update
                </button>
              </form>
            ) : (
              <>
                <p className="comment-text" style={{ color: '#ccc' }}>{c.text}</p>
                {user?.username === c.username && (
                  <div style={{ marginTop: '4px' }}>
                    <button onClick={() => handleEdit(c.commentId, c.text)} className="comment-action" style={{ marginRight: '10px', color: 'gold', background: 'transparent', border: 'none', cursor: 'pointer' }}>
                      ✏️ Edit
                    </button>
                    <button onClick={() => handleDelete(c.commentId)} className="comment-action" style={{ color: 'red', background: 'transparent', border: 'none', cursor: 'pointer' }}>
                      🗑️ Delete
                    </button>
                  </div>
                )}
              </>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}

export default VideoPlayer

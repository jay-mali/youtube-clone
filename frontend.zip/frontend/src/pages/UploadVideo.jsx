import React, { useState, useContext } from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'
import { AuthContext } from '../context/AuthContext'
import './UploadVideo.css'

const UploadVideo = () => {
  const { user } = useContext(AuthContext)
  const navigate = useNavigate()

  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [category, setCategory] = useState('Music')
  const [thumbnail, setThumbnail] = useState(null)
  const [preview, setPreview] = useState(null)
  const [videoUrl, setVideoUrl] = useState('')

  const handleThumbnailChange = (e) => {
    const file = e.target.files[0]
    setThumbnail(file)
    setPreview(URL.createObjectURL(file))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    const token = localStorage.getItem('token')

    let thumbnailBase64 = ''
    if (thumbnail) {
      const reader = new FileReader()
      reader.readAsDataURL(thumbnail)
      await new Promise(resolve => {
        reader.onloadend = () => {
          thumbnailBase64 = reader.result
          resolve()
        }
      })
    }

    try {
      await axios.post('http://localhost:5000/api/videos/upload', {
        title,
        description,
        category,
        thumbnail: thumbnailBase64,
        videoUrl
      }, {
        headers: { Authorization: `Bearer ${token}` }
      })

      alert('✅ Video uploaded!')
      navigate('/')
    } catch (err) {
      alert('Upload failed')
    }
  }

  return (
    
   <div className="upload-page">
    <h2 className="upload-heading">Upload Video</h2>
      
      <form onSubmit={handleSubmit}>
        <label>Title:</label>
        <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} required />

        <label>Description:</label>
        <textarea value={description} onChange={(e) => setDescription(e.target.value)} required />

        <label>Category:</label>
        <select value={category} onChange={(e) => setCategory(e.target.value)}>
          <option>Music</option>
          <option>Gaming</option>
          <option>Education</option>
          <option>News</option>
          <option>Comedy</option>
        </select>

        <label>Thumbnail:</label>
        <input type="file" accept="image/*" onChange={handleThumbnailChange} />
        {preview && <img src={preview} alt="Thumbnail preview" className="thumbnail-preview" />}

        <label>YouTube Video Link:</label>
        <input type="text" value={videoUrl} onChange={(e) => setVideoUrl(e.target.value)} required />

        <button type="submit">Upload</button>
      </form>
    </div>
  )
}

export default UploadVideo

import React, { useState, useContext } from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'
import { AuthContext } from '../context/AuthContext'
import './SignIn.css'

const SignIn = () => {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const { setUser } = useContext(AuthContext)
  const navigate = useNavigate()

  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      // ✅ Step 1: Sync Google Form data to MongoDB
      await axios.post('http://localhost:5000/api/auth/sync-users')

      // ✅ Step 2: Attempt login
      const res = await axios.post('http://localhost:5000/api/auth/login', {
        email,
        password,
      })

      // ✅ Step 3: Store token and user, update context
      localStorage.setItem('token', res.data.token)
      
      setUser(res.data.user)
      window.location.href = '/'

      // ✅ Step 4: Redirect to homepage
      navigate('/')
    } catch (err) {
      alert('Login failed. Please check your credentials.')
    }
  }

  return (
    <div className="signin-page">
      <form className="signin-form" onSubmit={handleSubmit}>
        <h2>Sign In</h2>
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        <button type="submit">Sign In</button>
      </form>

      <p className="register-link">
        Not registered?{' '}
        <a
          href="https://forms.gle/5gxrLwXbve1DeWjz8"
          target="_blank"
          rel="noopener noreferrer"
        >
          Click here to register  [if not already registered]
        </a>
      </p>
    </div>
  )
}

export default SignIn

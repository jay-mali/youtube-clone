import React, { useEffect, useState, useContext } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import axios from 'axios'
import VideoCard from '../components/VideoCard'
import { AuthContext } from '../context/AuthContext'
import './Channel.css'

const Channel = () => {
  const params = useParams()
  const navigate = useNavigate()
  const { user } = useContext(AuthContext)

  const id = params.id || user?.channel?._id

  const [channel, setChannel] = useState(null)
  const [videos, setVideos] = useState([])

  useEffect(() => {
    const fetchChannel = async () => {
      if (!id) return
      try {
        const res = await axios.get(`http://localhost:5000/api/channel/${id}`)
        setChannel(res.data.channel)
      } catch (err) {
        console.warn('Channel fetch failed, using user.channel if available.')
        setChannel(user?.channel || null)
      }
    }

    const fetchVideos = async () => {
      if (!id) return
      try {
        const res = await axios.get(`http://localhost:5000/api/videos/channel/${id}`)
        setVideos(res.data.videos)
        console.log("🎬 Videos fetched from API:", res.data.videos)
    
      } catch (err) {
        console.error('Error fetching videos:', err)
      }
    }

    fetchChannel()
    fetchVideos()
  }, [id, user])

  const handleDelete = async (videoId) => {
    if (!window.confirm('Are you sure you want to delete this video?')) return

    try {
      const token = localStorage.getItem('token')
      await axios.delete(`http://localhost:5000/api/videos/${videoId}`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      setVideos(videos.filter(v => v._id !== videoId))
    } catch (err) {
      alert('Failed to delete video')
    }
  }

  const displayChannel = channel || user?.channel

  if (!displayChannel) {
    return (
      <div className="channel-page" style={{ backgroundColor: '#000', color: 'white', padding: '40px' }}>
        <h2 style={{ color: 'gold' }}>No Channel Found</h2>
        <p style={{ color: '#ccc' }}>You haven't created a channel yet.</p>
        <button
          style={{ marginTop: '20px', padding: '10px 20px', backgroundColor: 'gold', border: 'none', color: 'black' }}
          onClick={() => navigate('/create-channel')}
        >
          Create Your Channel
        </button>
      </div>
    )
  }

  return (
    <div className="channel-page" style={{ backgroundColor: '#000', color: 'white' }}>
      <div className="channel-header" style={{ display: 'flex', alignItems: 'center', gap: '20px', padding: '20px' }}>
        <img
          src={
            displayChannel.avatar ||
            `https://api.dicebear.com/7.x/bottts/svg?seed=${displayChannel.handle || 'default'}`
          }
          alt="Avatar"
          className="channel-avatar"
          style={{ width: '100px', height: '100px', borderRadius: '50%', border: '2px solid gold' }}
        />
        <div>
          <h2 style={{ color: 'gold', margin: 0 }}>{displayChannel.name}</h2>
          <p style={{ color: '#ccc' }}>{displayChannel.handle}</p>
        </div>
      </div>

      <h3 className="video-heading" style={{ paddingLeft: '20px' }}>Videos</h3>
      <div className="channel-videos" style={{ display: 'flex', flexWrap: 'wrap', padding: '20px' }}>
        {videos.length > 0 ? (
          videos.map(video => (
            <div key={video._id} className="channel-video-item" style={{ marginRight: '20px', marginBottom: '20px' }}>
              <VideoCard video={video} />
              {user?.channel?._id === displayChannel._id && (
                <div className="video-actions">
                  <button className="edit-btn">✏️ Edit</button>
                  <button className="delete-btn" onClick={() => handleDelete(video._id)}>🗑️ Delete</button>
                </div>
              )}
            </div>
          ))
        ) : (
          <p style={{ color: '#999', fontStyle: 'italic' }}>
            This channel has no videos yet.
          </p>
        )}
      </div>
    </div>
  )
}

export default Channel

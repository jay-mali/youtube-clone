import React, { useState } from 'react'
import Header from './Header'
import Sidebar from './Sidebar'
import './Layout.css' // optional, if you want layout-specific styling

const Layout = ({ children }) => {
  const [showSidebar, setShowSidebar] = useState(true)

  return (
    <div>
      <Header onToggleSidebar={() => setShowSidebar(prev => !prev)} />
      <div className="home-layout">
        {showSidebar && <Sidebar />}
        <main className="main-content">{children}</main>
      </div>
    </div>
  )
}

export default Layout

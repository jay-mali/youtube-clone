import React from 'react'
import { Link } from 'react-router-dom'
import './Sidebar.css'

const Sidebar = ({ collapsed, overlay = false, onClose }) => {
  return (
    <aside className={`sidebar ${collapsed ? 'collapsed' : 'expanded'} ${overlay ? 'overlay' : ''}`}>
      {overlay && <div className="overlay-backdrop" onClick={onClose}></div>}

      <ul>
        <li>
          <Link to="/" className="sidebar-link">
            <span className="icon">🏠</span>
            {!collapsed && <span className="label">Home</span>}
          </Link>
        </li>
        <li><span className="icon">🎬</span>{!collapsed && <span className="label">Shorts</span>}</li>
        <li><span className="icon">📺</span>{!collapsed && <span className="label">Subscriptions</span>}</li>
        <hr />
        <li><span className="icon">🕓</span>{!collapsed && <span className="label">History</span>}</li>
        <li><span className="icon">📁</span>{!collapsed && <span className="label">Playlists</span>}</li>
        <li><span className="icon">📹</span>{!collapsed && <span className="label">Your Videos</span>}</li>
      </ul>
    </aside>
  )
}

export default Sidebar

import React from 'react'
import './FilterBar.css'

const categories = [
  "All", "Music", "News", "React", "Node.js", "Gaming", "Movies", "Trending", "Live", "Coding"
]

const FilterBar = ({ onSelectCategory, selected }) => {
  return (
    <div className="filter-bar">
      {categories.map((category, i) => (
        <button
          key={i}
          className={`filter-btn ${selected === category ? 'active' : ''}`}
          onClick={() => onSelectCategory(category)}
        >
          {category}
        </button>
      ))}
    </div>
  )
}

export default FilterBar

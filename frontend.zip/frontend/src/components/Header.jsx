import React, { useContext, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { AuthContext } from '../context/AuthContext'
import './Header.css'

const Header = ({ onToggleSidebar, onSearch }) => {
  const { user, logout } = useContext(AuthContext)
  const [dropdownOpen, setDropdownOpen] = useState(false)
  const navigate = useNavigate()

  const toggleDropdown = () => {
    setDropdownOpen((prev) => !prev)
  }

  const handleCreateChannel = () => {
    navigate('/create-channel')
    setDropdownOpen(false)
  }

  const handleViewChannel = () => {
    navigate(`/channel/${user.channel._id}`)
    setDropdownOpen(false)
  }

  return (
    <header className="header">
      <div className="left-section">
        <button className="hamburger" onClick={onToggleSidebar}>☰</button>
        <Link to="/">
          <img
            src="https://www.gstatic.com/youtube/img/branding/youtubelogo/svg/youtubelogo.svg"
            alt="YouTube"
            className="logo"
          />
        </Link>
      </div>

      <div className="middle-section">
        <input
          type="text"
          placeholder="Search"
          className="search-bar"
          onChange={(e) => onSearch && onSearch(e)}
        />
        <button className="search-btn">🔍</button>
        <button className="mic-btn">🎤</button>
      </div>

      <div className="right-section">
        {user?.channel && (
          <Link to="/upload">
            <button className="upload-btn">Upload Video</button>
          </Link>
        )}

        <button className="icon-btn">🔔</button>

        {user ? (
          <div className="user-dropdown">
            <div onClick={toggleDropdown} className="user-info">
              {user.channel?.avatar && (
                <img
                  src={user.channel.avatar}
                  alt="Avatar"
                  className="avatar"
                />
              )}
              <span className="username">
                {user.channel ? user.channel.name : user.username} ⌄
              </span>
            </div>

            {dropdownOpen && (
              <div className="dropdown-menu">
                {!user.channel && (
                  <button onClick={handleCreateChannel}>Create Channel</button>
                )}
                {user.channel && (
                  <button onClick={handleViewChannel}>View My Channel</button>
                )}
                <button onClick={logout}>Logout</button>
              </div>
            )}
          </div>
        ) : (
          <Link to="/signin">
            <button className="sign-in-btn">Sign In</button>
          </Link>
        )}
      </div>
    </header>
  )
}

export default Header

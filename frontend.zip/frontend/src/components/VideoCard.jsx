import React from 'react';
import './VideoCard.css';
import { Link } from 'react-router-dom';

const VideoCard = ({ video }) => {
  return (
    <Link to={`/video/${video.videoId}`} className="video-card-link">
      <div className="video-card">
        <img className="thumbnail" src={video.thumbnailUrl} alt="Thumbnail" />
        <div className="video-info">
          <img className="channel-avatar" src={video.avatar} alt="Avatar" />
          <div className="video-meta">
            <h4 className="title">{video.title}</h4>
            <p className="channel">{video.uploader}</p>
            <p className="stats">{video.views.toLocaleString()} views • {video.uploadDate}</p>
            
          </div>
        </div>
      </div>
    </Link>
  );
};

export default VideoCard;

const videos = [
  {
    videoId: "video01",
    title: "React Tutorial for Beginners",
    thumbnailUrl: "https://i.ytimg.com/vi/Ke90Tje7VS0/hqdefault.jpg",
    channelId: "channel01",
    uploader: "Code with John",
    views: 15200,
    uploadDate: "2024-09-20",
    avatar: "https://randomuser.me/api/portraits/men/1.jpg",
    category: "React",
    likes: 1200,
    dislikes: 45,
    comments: [
      { username: "Alice", text: "Very clear explanation. Helped a lot!" },
      { username: "Bob", text: "Thanks John, keep it up!" },
      { username: "Sam", text: "Would love a follow-up on Hooks." },
      { username: "Riya", text: "Awesome content as always!" },
      { username: "Ahmed", text: "Perfect for beginners!" }
    ]
  },
  {
    videoId: "video02",
    title: "Node.js Crash Course",
    thumbnailUrl: "https://i.ytimg.com/vi/ENrzD9HAZK4/hqdefault.jpg",
    channelId: "channel02",
    uploader: "Dev Tutorials",
    views: 22300,
    uploadDate: "2024-08-15",
    avatar: "https://randomuser.me/api/portraits/men/2.jpg",
    category: "Node.js",
    likes: 870,
    dislikes: 32,
    comments: [
      { username: "Liam", text: "Node explained so easily!" },
      { username: "Emma", text: "I finally get event loop, thanks!" },
      { username: "Noah", text: "More backend videos please!" },
      { username: "Olivia", text: "This crash course is gold." },
      { username: "Ava", text: "Subscribed for more content!" }
    ]
  },
  {
    videoId: "video03",
    title: "Top 10 JavaScript Tricks",
    thumbnailUrl: "https://i.ytimg.com/vi/Bv_5Zv5c-Ts/hqdefault.jpg",
    channelId: "channel03",
    uploader: "Daily Dev Tips",
    views: 18700,
    uploadDate: "2024-07-10",
    avatar: "https://randomuser.me/api/portraits/men/3.jpg",
    category: "Coding",
    likes: 1420,
    dislikes: 51,
    comments: [
      { username: "Tom", text: "I only knew 3 of them!" },
      { username: "Jane", text: "Number 7 blew my mind." },
      { username: "Arjun", text: "JS is powerful indeed." },
      { username: "Elena", text: "Please do Python tricks next!" },
      { username: "Marcus", text: "I’m using these in my project now." }
    ]
  },
  {
    videoId: "video04",
    title: "Tech News Today",
    thumbnailUrl: "https://i.ytimg.com/vi/dQw4w9WgXcQ/hqdefault.jpg",
    channelId: "channel04",
    uploader: "TechWorld News",
    views: 5300,
    uploadDate: "2024-09-01",
    avatar: "https://randomuser.me/api/portraits/men/4.jpg",
    category: "News",
    likes: 410,
    dislikes: 19,
    comments: [
      { username: "Sunny", text: "Very informative." },
      { username: "Chris", text: "Daily dose of tech delivered." },
      { username: "Amir", text: "What’s your take on AI news?" },
      { username: "Sophia", text: "Loved the Samsung segment." },
      { username: "Ryan", text: "Clean delivery and visuals!" }
    ]
  },
  {
    videoId: "video05",
    title: "Trending Dev Tools in 2024",
    thumbnailUrl: "https://i.ytimg.com/vi/9sT03jEwcaw/hqdefault.jpg",
    channelId: "channel03",
    uploader: "Daily Dev Tips",
    views: 19800,
    uploadDate: "2024-07-27",
    avatar: "https://randomuser.me/api/portraits/men/3.jpg",
    category: "Trending",
    likes: 1100,
    dislikes: 34,
    comments: [
      { username: "Nina", text: "Thanks! I discovered new tools." },
      { username: "Zack", text: "ESLint & Prettier for life." },
      { username: "Mila", text: "Where’s ChatGPT here? 😄" },
      { username: "Leo", text: "Tool 4 is my personal fav." },
      { username: "Daisy", text: "Can you review productivity tools too?" }
    ]
  },
  {
    videoId: "video06",
    title: "Live Coding Session",
    thumbnailUrl: "https://i.ytimg.com/vi/GFO_txvwK_c/hqdefault.jpg",
    channelId: "channel05",
    uploader: "Live Dev Show",
    views: 11400,
    uploadDate: "2024-07-01",
    avatar: "https://randomuser.me/api/portraits/men/5.jpg",
    category: "Live",
    likes: 950,
    dislikes: 20,
    comments: [
      { username: "DevFan", text: "Love watching you debug!" },
      { username: "Vikram", text: "So raw and real." },
      { username: "Clara", text: "Thanks for showing your thought process." },
      { username: "Rohan", text: "This helped me so much!" },
      { username: "Becca", text: "Keep doing live streams!" }
    ]
  },
  {
    videoId: "video07",
    title: "Apex Legends Pro Gameplay",
    thumbnailUrl: "https://i.ytimg.com/vi/K4TOrB7at0Y/hqdefault.jpg",
    channelId: "channel06",
    uploader: "Pro Gamer",
    views: 45000,
    uploadDate: "2024-06-18",
    avatar: "https://randomuser.me/api/portraits/men/6.jpg",
    category: "Gaming",
    likes: 3850,
    dislikes: 60,
    comments: [
      { username: "Jake", text: "That triple kill though 🔥" },
      { username: "Rita", text: "You make it look easy!" },
      { username: "Max", text: "What mouse do you use?" },
      { username: "Amy", text: "GG well played." },
      { username: "Kyle", text: "Legend at work!" }
    ]
  },
  {
    videoId: "video08",
    title: "Top 10 Must-Watch Movies",
    thumbnailUrl: "https://i.ytimg.com/vi/YoHD9XEInc0/hqdefault.jpg",
    channelId: "channel07",
    uploader: "Movie World",
    views: 81000,
    uploadDate: "2024-07-20",
    avatar: "https://randomuser.me/api/portraits/men/7.jpg",
    category: "Movies",
    likes: 5100,
    dislikes: 78,
    comments: [
      { username: "Fanatic", text: "Interstellar is #1 for me!" },
      { username: "Monica", text: "Great recommendations." },
      { username: "Peter", text: "Thanks! Binge list ready." },
      { username: "Karan", text: "Well curated list!" },
      { username: "Tina", text: "Watched 8 out of 10 already 😄" }
    ]
  },
  {
    videoId: "video09",
    title: "React vs Angular: Which to Choose?",
    thumbnailUrl: "https://i.ytimg.com/vi/2Ji-clqUYnA/hqdefault.jpg",
    channelId: "channel01",
    uploader: "Code with John",
    views: 11900,
    uploadDate: "2024-09-10",
    avatar: "https://randomuser.me/api/portraits/men/1.jpg",
    category: "React",
    likes: 990,
    dislikes: 44,
    comments: [
      { username: "Abby", text: "React all the way!" },
      { username: "Mo", text: "Angular is underrated." },
      { username: "Lee", text: "Great comparison." },
      { username: "Dan", text: "Thanks, this helped me decide!" },
      { username: "Grace", text: "Neutral but good overview!" }
    ]
  },
  {
    videoId: "video10",
    title: "Top Songs of 2024 🎵",
    thumbnailUrl: "https://i.ytimg.com/vi/CuklIb9d3fI/hqdefault.jpg",
    channelId: "channel08",
    uploader: "Music Hub",
    views: 105000,
    uploadDate: "2024-08-02",
    avatar: "https://randomuser.me/api/portraits/men/8.jpg",
    category: "Music",
    likes: 8200,
    dislikes: 103,
    comments: [
      { username: "DJVibes", text: "On repeat!" },
      { username: "Sana", text: "This playlist slaps!" },
      { username: "Harsh", text: "Can’t stop grooving!" },
      { username: "Riko", text: "You missed Song X!" },
      { username: "Fiona", text: "Loved #3 in the list." }
    ]
  },
  {
    videoId: "video11",
    title: "Build a MERN App Step-by-Step",
    thumbnailUrl: "https://i.ytimg.com/vi/4Z9KEBexzcM/hqdefault.jpg",
    channelId: "channel02",
    uploader: "Dev Tutorials",
    views: 24000,
    uploadDate: "2024-08-25",
    avatar: "https://randomuser.me/api/portraits/men/2.jpg",
    category: "Node.js",
    likes: 1750,
    dislikes: 52,
    comments: [
      { username: "Neha", text: "Best MERN tutorial!" },
      { username: "Mike", text: "Why didn’t I see this before?" },
      { username: "Lata", text: "Subscribed instantly." },
      { username: "Jon", text: "Full stack for the win!" },
      { username: "Raj", text: "Can you do authentication next?" }
    ]
  },
  {
    videoId: "video12",
    title: "CSS Grid vs Flexbox",
    thumbnailUrl: "https://i.ytimg.com/vi/FEnRpy9Xfes/hqdefault.jpg",
    channelId: "channel04",
    uploader: "Web Dev Simplified",
    views: 13400,
    uploadDate: "2024-06-15",
    avatar: "https://randomuser.me/api/portraits/men/9.jpg",
    category: "Web Dev",
    likes: 1120,
    dislikes: 28,
    comments: [
      { username: "Sara", text: "Grid makes life easy!" },
      { username: "Nate", text: "Flexbox is all I need!" },
      { username: "Luis", text: "Comparison is great." },
      { username: "Kate", text: "Can you do layout challenges?" },
      { username: "Henry", text: "This cleared my confusion." }
    ]
  },
  {
    videoId: "video13",
    title: "JavaScript Async Await Tutorial",
    thumbnailUrl: "https://i.ytimg.com/vi/V_Kr9OSfDeU/hqdefault.jpg",
    channelId: "channel03",
    uploader: "Daily Dev Tips",
    views: 19000,
    uploadDate: "2024-07-22",
    avatar: "https://randomuser.me/api/portraits/men/3.jpg",
    category: "Coding",
    likes: 1380,
    dislikes: 37,
    comments: [
      { username: "Jay", text: "Clear and concise." },
      { username: "Maya", text: "Async is no more scary." },
      { username: "Paul", text: "Your visuals are amazing!" },
      { username: "Kiara", text: "Thanks for explaining!" },
      { username: "Alex", text: "Can you explain error handling too?" }
    ]
  },
  {
    videoId: "video14",
    title: "Live Debugging a Node App",
    thumbnailUrl: "https://i.ytimg.com/vi/o1IaduQICO0/hqdefault.jpg",
    channelId: "channel05",
    uploader: "Live Dev Show",
    views: 7200,
    uploadDate: "2024-06-20",
    avatar: "https://randomuser.me/api/portraits/men/5.jpg",
    category: "Live",
    likes: 860,
    dislikes: 24,
    comments: [
      { username: "George", text: "Real-time debugging is 🔥" },
      { username: "Amit", text: "More of this format please!" },
      { username: "Jade", text: "Great learnings." },
      { username: "Milo", text: "You saved my project!" },
      { username: "Ella", text: "Love your teaching style." }
    ]
  }
]

export default videos


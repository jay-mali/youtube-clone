const channels = [
    {
      channelId: "channel01",
      channelName: "Code with John",
      owner: "user01",
      description: "Coding tutorials and tech reviews by John Doe.",
      channelBanner: "https://via.placeholder.com/1280x240.png?text=Channel+Banner",
      avatar: "https://yt3.ggpht.com/ytc/AKedOLQj0v6.png",
      subscribers: 5200,
      videos: ["video01"]
    },
    {
      channelId: "channel02",
      channelName: "Dev Tutorials",
      owner: "user02",
      description: "Web development tutorials and dev tips.",
      channelBanner: "https://via.placeholder.com/1280x240.png?text=Dev+Channel",
      avatar: "https://yt3.ggpht.com/ytc/AKedOLSRqk.png",
      subscribers: 3100,
      videos: ["video02"]
    }
  ]
  
  export default channels
  
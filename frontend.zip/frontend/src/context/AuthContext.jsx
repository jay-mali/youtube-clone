import { createContext, useState, useEffect } from 'react'
import axios from 'axios'

export const AuthContext = createContext()

const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null)

  const fetchUserAndChannel = async () => {
    const token = localStorage.getItem('token')
    if (!token) return
  
    try {
      const res = await axios.get('http://localhost:5000/api/auth/me', {
        headers: { Authorization: `Bearer ${token}` },
      })
  
      const userData = res.data.user
  
      // Fetch channel info without crashing user context
      try {
        const channelRes = await axios.get(`http://localhost:5000/api/channel/${userData._id}`)
        const channelData = channelRes.data.channel
  
        if (channelData) {
          userData.channel = channelData // ✅ Assign actual channel object
        } else {
          userData.channel = null
        }
      } catch (err) {
        console.warn('No channel yet or channel fetch failed:', err.message)
        userData.channel = null
      }
  
      // ✅ Final user set, with or without channel
      setUser(userData)
    } catch (err) {
      console.error('Error fetching user:', err.message)
      localStorage.removeItem('token')
      setUser(null)
    }
  }
  
  useEffect(() => {
    fetchUserAndChannel()
  }, [])

  const logout = () => {
    localStorage.removeItem('token')
    setUser(null)
  }

  return (
    <AuthContext.Provider value={{ user, setUser, logout, refreshUser: fetchUserAndChannel }}>
      {children}
    </AuthContext.Provider>
  )
}

export default AuthProvider

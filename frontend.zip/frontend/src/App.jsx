import React, { useState } from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Home from './pages/Home'
import VideoPlayer from './pages/VideoPlayer'
import Channel from './pages/Channel'
import SignIn from './pages/SignIn'
import UploadVideo from './pages/UploadVideo'
import CreateChannel from './pages/CreateChannel'
import AuthProvider from './context/AuthContext'
import ProtectedRoute from './components/ProtectedRoute'
import Header from './components/Header'
import Sidebar from './components/Sidebar'

const Layout = ({ children, showSidebar, setShowSidebar }) => (
  <>
    <Header onToggleSidebar={() => setShowSidebar(prev => !prev)} />
    <div className="home-layout">
      {showSidebar && <Sidebar collapsed={false} />}
      <main className="main-content">{children}</main>
    </div>
  </>
)

const App = () => {
  const [showSidebar, setShowSidebar] = useState(true)

  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route
            path="/"
            element={
              <Home showSidebar={showSidebar} setShowSidebar={setShowSidebar} />
            }
          />
          <Route
            path="/video/:id"
            element={
              <Layout showSidebar={showSidebar} setShowSidebar={setShowSidebar}>
                <VideoPlayer />
              </Layout>
            }
          />
          <Route
            path="/channel/:id"
            element={
              <Layout showSidebar={showSidebar} setShowSidebar={setShowSidebar}>
                <Channel />
              </Layout>
            }
          />
          <Route
            path="/signin"
            element={
              <Layout showSidebar={showSidebar} setShowSidebar={setShowSidebar}>
                <SignIn />
              </Layout>
            }
          />
          <Route
            path="/upload"
            element={
              <Layout showSidebar={showSidebar} setShowSidebar={setShowSidebar}>
                <UploadVideo />
              </Layout>
            }
          />
          <Route
            path="/create-channel"
            element={
              <ProtectedRoute>
                <Layout showSidebar={showSidebar} setShowSidebar={setShowSidebar}>
                  <CreateChannel />
                </Layout>
              </ProtectedRoute>
            }
          />
           <Route path="/channel/:id" element={<Channel />} />
<Route path="/channel" element={<Channel />} />


        </Routes>
      </Router>
    </AuthProvider>
  )
}

export default App

import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import rollupNodePolyFill from 'rollup-plugin-polyfill-node'

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      crypto: 'rollup-plugin-polyfill-node/polyfills/crypto-browserify',
      stream: 'rollup-plugin-polyfill-node/polyfills/stream',
      buffer: 'rollup-plugin-polyfill-node/polyfills/buffer-es6',
    }
  },
  define: {
    global: 'globalThis',
  },
  optimizeDeps: {
    include: ['crypto', 'stream', 'buffer'],
  },
  build: {
    rollupOptions: {
      plugins: [rollupNodePolyFill()]
    }
  }
})

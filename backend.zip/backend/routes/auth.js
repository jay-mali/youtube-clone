import express from 'express'
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
import User from '../models/User.js'
import authMiddleware from '../middleware/authMiddleware.js'
import { syncUsersFromGoogleSheet } from '../syncGoogleFormUsers.js'  // ✅ Import added

const router = express.Router()

// ✅ New route: sync Google Form users on demand
router.post('/sync-users', async (req, res) => {
  try {
    await syncUsersFromGoogleSheet()
    res.status(200).json({ message: 'Users synced successfully' })
  } catch (err) {
    console.error('❌ Sync error:', err)
    res.status(500).json({ message: 'Sync failed', error: err.message })
  }
})

router.post('/login', async (req, res) => {
  try {
    console.log('🟡 Login attempt:', req.body);

    const { email, password } = req.body;

    const user = await User.findOne({ email });
    if (!user) {
      console.log('🔴 No user found with that email');
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    console.log('🟢 User found:', user.email);

    const isMatch = await bcrypt.compare(password, user.password);
    console.log('🧪 Password match:', isMatch);

    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '7d' });

    res.json({
      token,
      user: { id: user._id, username: user.username, email: user.email },
    });

  } catch (err) {
    console.error('❌ Login error:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get current user
router.get('/me', authMiddleware, async (req, res) => {
  try {
    const user = await User.findById(req.userId).select('-password')
    res.json({ user })
  } catch (err) {
    res.status(500).json({ message: 'Server error' })
  }
})

export default router

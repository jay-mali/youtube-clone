import express from 'express'
import Channel from '../models/Channel.js'
import authMiddleware from '../middleware/authMiddleware.js'

const router = express.Router()

// Create channel (POST)
router.post('/create', authMiddleware, async (req, res) => {
  try {
    const { name, avatar } = req.body

    const existing = await Channel.findOne({ user: req.userId })
    if (existing) return res.status(400).json({ message: 'Channel already exists' })

    const channel = await Channel.create({
      name,
      avatar,
      user: req.userId,
    })

    res.status(201).json({ channel })
  } catch (err) {
    console.error(err)
    res.status(500).json({ message: 'Server error' })
  }
})

// Get a channel by userId
router.get('/:id', async (req, res) => {
  try {
    const channel = await Channel.findOne({ user: req.params.id })
    if (!channel) return res.status(404).json({ message: 'Channel not found' })

    res.json({ channel })
  } catch (err) {
    res.status(500).json({ message: 'Server error' })
  }
})

export default router

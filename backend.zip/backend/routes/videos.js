import express from 'express'
import Video from '../models/Video.js'
import authMiddleware from '../middleware/authMiddleware.js'

const router = express.Router()

// Get videos by channel
router.get('/channel/:channelId', async (req, res) => {
  try {
    const videos = await Video.find({ channel: req.params.channelId }).sort({ createdAt: -1 })
    res.json({ videos })
  } catch (err) {
    console.error('Fetch channel videos error:', err)
    res.status(500).json({ message: 'Failed to fetch videos' })
  }
})

// Delete a video
router.delete('/:id', authMiddleware, async (req, res) => {
  try {
    const video = await Video.findById(req.params.id)
    if (!video) return res.status(404).json({ message: 'Video not found' })

    if (video.uploader.toString() !== req.userId) {
      return res.status(403).json({ message: 'Unauthorized to delete this video' })
    }

    await Video.findByIdAndDelete(req.params.id)
    res.json({ message: 'Video deleted' })
  } catch (err) {
    console.error('Delete video error:', err)
    res.status(500).json({ message: 'Failed to delete video' })
  }
})

export default router

import { google } from 'googleapis'
import mongoose from 'mongoose'
import dotenv from 'dotenv'
import bcrypt from 'bcryptjs'
import User from './models/User.js'

dotenv.config()

export async function syncUsersFromGoogleSheet() {
  const auth = new google.auth.JWT(
    process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL,
    null,
    process.env.GOOGLE_PRIVATE_KEY.replace(/\\n/g, '\n'),
    ['https://www.googleapis.com/auth/spreadsheets.readonly']
  )

  await auth.authorize()

  const sheets = google.sheets({ version: 'v4', auth })
  const response = await sheets.spreadsheets.values.get({
    spreadsheetId: process.env.SHEET_ID,
    range: 'Form responses 1',
  })

  const rows = response.data.values
  const headers = rows[0]
  const dataRows = rows.slice(1)

  await mongoose.connect(process.env.MONGO_URI)

  for (let row of dataRows) {
    const rowData = {}
    headers.forEach((header, idx) => {
      rowData[header.trim()] = row[idx] ? row[idx].trim() : ''
    })

    const Email = rowData['Email address']
    const Username = rowData['Full Name']
    const Password = rowData['Password']

    if (!Email || !Username || !Password ) {
      console.log(`⚠️ Skipped invalid row (missing or short username):`, rowData)
      continue
    }

    const exists = await User.findOne({ email: Email })
    if (exists) {
      console.log(`❌ Skipped: ${Email} – Already registered`)
      continue
    }

    try {
      const hashedPassword = await bcrypt.hash(Password, 10)

      await User.create({
        email: Email,
        username: Username,
        password: hashedPassword,
      })

      console.log(`✅ Registered: ${Email}`)
    } catch (err) {
      console.error(`❌ Error saving ${Email}:`, err.message)
    }
  }

 
}

// fetchGoogleFormData.js
import { google } from 'googleapis';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import fs from 'fs';
import bcrypt from 'bcrypt';

dotenv.config();

// MongoDB connection
await mongoose.connect(process.env.MONGO_URI);

// Import your Mongoose model (update the path and schema accordingly)
import User from './models/User.js';

// Load Google Service Account credentials
const credentials = JSON.parse(fs.readFileSync('./google-credentials.json', 'utf8'));

const auth = new google.auth.GoogleAuth({
  credentials,
  scopes: ['https://www.googleapis.com/auth/spreadsheets.readonly'],
});

const sheets = google.sheets({ version: 'v4', auth });

const SPREADSHEET_ID = '1uWldz9fsIQ7rCI-8j0fH7k50IR8VU-1sZOLZSXeJzcA';
const RANGE = 'Form responses 1'; // Usually the first sheet name

try {
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId: SPREADSHEET_ID,
    range: RANGE,
  });

  const rows = res.data.values;

  if (rows.length) {
    const headers = rows[0];
    const dataRows = rows.slice(1);

    const users = dataRows.map(row => {
      const hashedPassword = bcrypt.hashSync('FormLogin123', 10); // ⬅️ default password hashed
      return {
        username: row[0], // adjust if needed
        email: row[1],
        password: hashedPassword,
      };
    });

    // Save to MongoDB
    for (const user of users) {
      // Prevent duplicates based on email or other key
      const exists = await User.findOne({ email: user.email });
      if (!exists) {
        await User.create(user);
      }
    }

    console.log('Data synced successfully!');
  } else {
    console.log('No data found in Google Sheet.');
  }
} catch (error) {
  console.error('Error fetching data from Google Sheets:', error.message);
}

console.log("✅ Connected to MongoDB:", mongoose.connection.name);
